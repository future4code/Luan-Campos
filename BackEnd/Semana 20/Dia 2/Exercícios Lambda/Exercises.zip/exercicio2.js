exports.handler = async (event) => {
  return "Olá, eu sou uma mensagem da AWS";
};
